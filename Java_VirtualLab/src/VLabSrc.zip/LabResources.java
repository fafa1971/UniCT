/*
 * @(#)LabResources.java
 *
 * Contiene la descrizione delle risorse disponibili per il client
 *
 * @author	Fabrizio Fazzino
 * @version	1.0		1996/XI/15
 */

import java.io.*;

public class LabResources {
	private static final int numberOfResources = 4;
	private int numberOfAccessibleResources = 0;
	private static final String resourceName[] = {
		"FabNet",
		"Date",
		"Time",
		"Dir"
	};
	private boolean resourceAccess[];
	
	// Costruttore (usato dal client) setta i permessi ricevuti.
	// Non importa se il client bara, tanto potr� solo ottenere
	// l'accesso all'interfaccia, mentre per le vere risorse il
	// server non guarda questa struttura ma utilizza le proprie
	public LabResources(boolean access[]) {
		if (access==null || access.length!=numberOfResources) {
			System.err.println("Numero di permessi non valido");
//			System.exit(1);
		} else {
			resourceAccess = access;
			for (int i=0; i<resourceAccess.length; i++) {
				if (resourceAccess[i]) numberOfAccessibleResources++;
			}
		}
	}

	// Ritorna il numero di risorse totali
	public int getNumberOfResources() {
		return numberOfResources;
	}

	// Ritorna il numero di risorse accessibili
	public int getNumberOfAccessibleResources() {
		return numberOfAccessibleResources;
	}

	// Ritorna il permesso su ogni risorsa
	public boolean getResourceAccess(int n) {
		if (n>=0 && n<numberOfResources)
			return resourceAccess[n];
		else return false;
	}

	// Restituisce una stringa per descrivere ogni risorsa posseduta
	public String getResourceName(int n) {
		if (n>=0 && n<numberOfResources && resourceAccess[n])
			return resourceName[n];
		else return null;
	}
}