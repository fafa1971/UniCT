/*
 * @(#)DataManager.java
 *
 * Classe di supporto per impacchettare e ricomporre i dati
 *
 * @author	Fabrizio Fazzino
 * @version	1.0		1996/XI/16
 */

import java.io.*;

public final class DataManager {

	/* Quando voglio spedire delle stringhe nel socket,
	esse non vengono trasformate direttamente in bytes
	ma viene creata una struttura del seguente tipo:

		bytes[0] = n = numero di stringhe;
		bytes[1]...bytes[n] = lunghezza di ognuna delle n stringhe;
		bytes[n+1]...bytes[n+bytes[1]] = stringa 0;
		bytes[n+bytes[1]+1]...bytes[n+bytes[1]+bytes[2]] = stringa 1;
		...
		bytes[n+bytes[1]+...+bytes[n-1]+1]...bytes[n+bytes[1]+..+bytes[n]] =
			= stringa n-1

	In tal modo la destinazione pu� facilmente compiere
	il procedimento inverso per ricavare le stringhe.

	Nel caso in cui i dati debbano essere cifrati, essi alla sorgente
	vanno prima impacchettati in array di byte, poi cifrati e spediti,
	e alla destinazione vanno decifrati e ricomposti come stringhe.

	N.B. Si vede che deve valere la propriet�:
		bytes.length == bytes[0]+bytes[1]+...+bytes[n]+1
	In pratica per� mi accontento che sia >= , perch� la cifratura
	potrebbe richiedere l'aggiunta di caratteri di riempimento.
	*/

	// Ricompone i dati tirati fuori dal socket
	public static String[] bytesToStrings(byte bytes[]) {
		String strings[] = null;

		if (bytes==null || bytes.length==0) {
			return strings;
		} else {
			int n = bytes[0];
			if (bytes.length < n+1) {
				return strings;
			} else {
				int utilBytes=1;
				for (int z=0; z<=n; z++)
					utilBytes += bytes[z];
				if (utilBytes > bytes.length) {
					return strings;
				} else {
					strings = new String[n];
					for (int i=0; i<n; i++) {
						int count = (int)bytes[i+1];
						int offset=1;
						for (int x=0; x<=i; x++)
							offset += bytes[x];
						strings[i] = new String(bytes,0,offset,count);
					}
				}
			}
		}
		return strings;
	}

	// Impacchetta le stringhe in array di byte da spedire
	public static byte[] stringsToBytes(String strings[]) {
		byte bytes[] = null;

		if (strings!=null && strings.length!=0) {
			int args = strings.length;
			int totalLength = 0;
			for (int s=0; s<args; s++)
				totalLength += strings[s].length();

			bytes = new byte[1+args+totalLength];
			bytes[0] = (byte)args;
			for (int a=0; a<args; a++) {
				int offset = 1+args;
				for (int k=0; k<a; k++)
					offset += strings[k].length();
				
				bytes[a+1] = (byte)strings[a].length();
				strings[a].getBytes(0,strings[a].length(),bytes,offset);
			}
		}

		return bytes;
	}

	// Converte stringa di 0 e 1 in array di boolean
	public static boolean[] stringToBooleans(String string) {
		boolean booleans[] = new boolean[string.length()];

		for (int i=0; i<string.length(); i++) {
			if (string.charAt(i)=='0') booleans[i]=false;
			else if (string.charAt(i)=='1') booleans[i]=true;
			else return null;
		}
		return booleans;
	}

	// Converte array di boolean in stringa di 0 e 1
	public static String booleansToString(boolean booleans[]) {
		StringBuffer string = new StringBuffer();

		for (int i=0; i<booleans.length; i++) {
			if (booleans[i]) string.append('1');
			else string.append('0');
		}
		return string.toString();
	}
}