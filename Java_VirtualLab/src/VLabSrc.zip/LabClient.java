/*
 * @(#)LabClient.java
 *
 * Client usata dall'applet per comunicare col server
 *
 * @author	Fabrizio Fazzino
 * @version	1.0		1996/XI/7
 */

import java.awt.*;
import java.net.*;
import java.io.*;

public class LabClient {
	public VirtualLab myBoss;        
	public Socket sok;
	public byte buffer[] = new byte[1024];

	// Costruttore apre il socket
	public LabClient(VirtualLab myIncomingBoss) {
		myBoss = myIncomingBoss;

		System.out.println("Inizializzo connessione col server...");

		// Apre la connessione con il server alla porta 6666
		try {
			sok=new Socket(InetAddress.getByName(myBoss.getCodeBase().getHost()),6666);
		} catch (IOException e) { }

		if (sok!=null) {
			System.out.println("Connessione riuscita");
		} else {
			System.out.println("Impossibile connettersi");
		}
	}

	// Invia stringa al server
	public void write(String data[]) {
		if (sok!=null) try {
			OutputStream outstream;
			outstream=sok.getOutputStream();
			outstream.write(DataManager.stringsToBytes(data));
		} catch (IOException e) { }
	}

	// Legge stringa dal server
	public String[] read() {
		String incomingData[] = null;

		if (sok!=null) try {
			InputStream instream;
			instream = sok.getInputStream();
			instream.read(buffer);
			incomingData = DataManager.bytesToStrings(buffer);

			System.out.println("LabClient.read(): letto "+incomingData.length+" stringhe");

		} catch (IOException e) { }
	
		return incomingData;
	}

	// Chiude la connessione
	public void close() {
		if (sok!=null) try {
			sok.close();
		} catch (IOException e) { }
	}

	// Gestisce il protocollo di autenticazione
	public boolean[] Authentication(String leavingData[]) {
		boolean accessArray[] = null;
		
		if (sok != null) {

			// qui cifro userName e cryptedPassword

			// spedisco userName e cryptedPassword
			System.out.println("Spedisco "+leavingData[0]+"+"+leavingData[1]);
			write(leavingData);

			// ricevo i permessi
			String incomingData[] = read();
			System.out.println("Ricevuto accessi "+incomingData[0]);
			
			// qui la stringa ricevuta va decifrata
			accessArray = DataManager.stringToBooleans(incomingData[0]);
		}
		return accessArray;
	}

	// Gestisce il protocollo Request/Reply
	public String[] RequestReply(String request[]) {
		String reply[] = null;
		
		if (sok != null) {
			// spedisco la richiesta
			System.out.println("Spedisco richiesta - stringhe "+request.length);
			write(request);

			// ricevo la risposta
			reply = read();
			System.out.println("Ricevuto risposta - stringhe "+reply.length);
		}
		return reply;
	}



}
