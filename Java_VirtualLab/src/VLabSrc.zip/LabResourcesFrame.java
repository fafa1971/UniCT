/*
 * @(#)LabResourcesFrame.java
 * 
 * Finestra per scegliere una delle risorse accessibili
 *
 * @author	Fabrizio Fazzino
 * @version	1.0		1996/XI/19
 */

import java.awt.*;

public class LabResourcesFrame extends Frame {
	private VirtualLab myBoss;
	
	private GridBagLayout myGrid = new GridBagLayout();
	private GridBagConstraints myGridPos = new GridBagConstraints();
	private Label myLabel = new Label();
	private Button bottoniera[] = null;

	public LabResourcesFrame(VirtualLab myIncomingBoss) {
		super ("Lab resources index");
		myBoss = myIncomingBoss;

		bottoniera = new Button[myBoss.myResources.getNumberOfAccessibleResources()];

		setLayout(myGrid);

		myLabel.setText("Le risorse accessibili sono le seguenti : ");
		myGridPos.gridx = 0;
		myGridPos.gridy = 0;
		myGrid.setConstraints(myLabel,myGridPos);
		add(myLabel);

		int buttonNumber = 0;
		for(int i=0; i<myBoss.myResources.getNumberOfResources(); i++) {
			if(myBoss.myResources.getResourceAccess(i)) {
				bottoniera[buttonNumber++] = new Button(myBoss.myResources.getResourceName(i));
				myGridPos.gridx = 0;
				myGridPos.gridy = buttonNumber;
				myGrid.setConstraints(bottoniera[buttonNumber-1],myGridPos);
				add(bottoniera[buttonNumber-1]);
			}
		}

		reshape(100,100,300,300);
		show();
		reshape(100,100,300,300);
	}
	

	public boolean handleEvent(Event ev) {
		// Chiudo la finestra di dialogo		
		if (ev.id == Event.WINDOW_DESTROY) {
			dispose();
			return true;
		}
		// Premo uno dei bottoni
		if (ev.target instanceof Button) {
			String label = (String)ev.arg;
			if (label.equals("FabNet")) {
				myBoss.myInputFrame = new InputFrame(myBoss,"FabNet");
				dispose();
				return true;
			}
			if (label.equals("Cancel")) {
				dispose();
				return true;
			}
		}
		return false;
	}


}
