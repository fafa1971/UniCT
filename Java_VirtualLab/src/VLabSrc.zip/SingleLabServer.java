/*
 * @(#)SingleLabServer.java
 *
 * Singolo server stand-alone per comunicare con utente remoto
 *
 * @author	Fabrizio Fazzino
 * @version	1.0		1996/XI/9
 */

import java.net.*;
import java.io.*;

public class SingleLabServer {
	private static ServerSocket sersok;
	private static Socket sok;
	private static byte buffer[] = new byte[70];

	// Inizializza il server sulla porta 6666
	private static void init() throws IOException {
		sersok=new ServerSocket(6666);
		System.out.println("Server attivato.");
	}

	// Serve ciclicamente le richieste dei client (protocollo)
	private static void run() throws IOException {
		while (true) {
			// Accetta la richiesta di un client
			sok=sersok.accept();

			// Legge dal socket UserName e Password
			InputStream instream;
			instream = sok.getInputStream();
			instream.read(buffer);
			String data[] = DataManager.bytesToStrings(buffer);

			// Verifica che l'utente sia registrato
			String access = checkUser(data[0],data[1]);
			String accesses[] = { access };

			// Manda messaggio di accettazione o rifiuto
			OutputStream outstream;
			outstream = sok.getOutputStream();
			outstream.write(DataManager.stringsToBytes(accesses));

			// Riceve ed esegue comando
//			instream = sok.getInputStream();
			instream.read(buffer);
			data = DataManager.bytesToStrings(buffer);
			System.out.println("Eseguo:"+data[0]);
			ExecutionThread myET = new ExecutionThread(data[0]);

			// Manda i risultati della operazione remota
			String response[] = myET.getExecutionResponse();
			System.out.println("Risposta di "+response.length+" stringhe:");
			for(int a=0; a<response.length; a++) {
				System.out.println("Riga "+a+": "+response[a]);
			}
//			outstream = sok.getOutputStream();
			outstream.write(DataManager.stringsToBytes(response));
		}			
	}

	// Verifica che l'utente sia registrato
	private static String checkUser(String userName, String cryptedPassword) throws IOException {
		String strings[] = null;
		String access = new String();

		FileManager myFile = new FileManager("data/passwd","r");

		while(true) {
			strings = myFile.readRecord();
			if (strings==null || strings.length<3) {
				break;
			} else if (strings[0].equals(userName) && strings[1].equals(cryptedPassword)) {
				access = new String(strings[2]);
				break;
			}
		}
		myFile.close();
		myFile = null;

		System.out.println("Rispedisco "+access);
		
		return access;
	}

	// Chiude la singola connessione
	private static void close() throws IOException {
		sok.close();
	}

	// Sequenza di operazioni per ogni connessione
	public static void main(String args[]) throws IOException {
		init();
		run();
		close();
	}
}
