/*
 * @(#)OutputFrame.java
 * 
 * Finestra per visualizzare i risultati delle interazioni
 *
 * @author	Fabrizio Fazzino
 * @version	1.0		1996/XI/8
 */

import java.awt.*;

public class OutputFrame extends Frame {
	public VirtualLab myBoss;
	
	public GridBagLayout myGrid = new GridBagLayout();
	public GridBagConstraints myGridPos = new GridBagConstraints();
	public Label myLabel = new Label();

	public OutputFrame(VirtualLab myIncomingBoss, String resourceName) {
		super ("Output Interface of "+resourceName);
		myBoss = myIncomingBoss;

		setLayout(myGrid);

		myLabel.setText("Inizializzo finestra di uscita...");
		myGridPos.gridx = 0;
		myGridPos.gridy = 0;
		myGrid.setConstraints(myLabel,myGridPos);
		add(myLabel);
		
		reshape(100,100,300,200);
		show();
		reshape(100,100,300,200);
	}
 
	public void updateLabel(String msg) {
		myLabel.setText(msg);
		repaint();
		show();
	}

	public boolean handleEvent(Event evt) {
		switch (evt.id)	{
			case Event.WINDOW_DESTROY:
				dispose();
//				System.exit(0);
				return true;

			default:
				return super.handleEvent(evt);
		}			 
	}
}
