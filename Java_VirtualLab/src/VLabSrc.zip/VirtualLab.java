/*
 * @(#)VirtualLab.java
 *
 * Applet che implementa il lato client del Virtual Lab
 *
 * @author	Fabrizio Fazzino
 * @version	1.0		1996/X/29
 */

import java.applet.*;
import java.awt.*;

public class VirtualLab extends Applet implements Runnable {
	
	// Supporto per animazione richiede thread multipli	
	Thread	VL_MainThread = null;
	private Graphics VL_Graphics;
	private Image	 VL_Images[];
	private int 	 VL_CurrImageNo;
	private int 	 VL_ImgWidth  = 0;
	private int 	 VL_ImgHeight = 0;
	private boolean  VL_AllLoaded = false;
	private final int NUM_IMAGES = 18;

	// Variabili generali per il disegno
	private Button buttonLogin;

	// Variabili per sincronizzare i vari thread
	public boolean LoginDialogActive = false;	// On=this, Off=dialog
	public boolean LoginOKPressed = false;		// On=dialog, Off=this
	public String executionCommand = null;
	public boolean executionCanStart = false;	// On=input, Off=client

	// Classi di supporto
	public LoginDialog myLoginDialog = null;
	public LabResources myResources = null;
	public LabClient myClient = null;

	public Frame myLoginDialogFrame = null;
	public LabResourcesFrame myResourcesFrame = null;
	public InputFrame myInputFrame = null;
//	public OutputFrame myOutputFrame = null;

	// Variabili utilizzate per memorizzare info riservate
	private String userName = new String();
	private String cryptedPassword = new String();
	
	// Restituisce info dell'applet
	public String getAppletInfo() {
		return "Name: VirtualLab 1.0\r\n\n" +
		       "Author: Fabrizio Fazzino\r\n" +
		       "E-mail: ffazzino@k200.cdc.unict.it\r\n\n" +
		       "Designed by the IIT of the University of Catania\r\n" +
		       "From an idea of O.Mirabella & A.Di Stefano\r\n" +
		       "With the help of L.Lo Bello\r\n\n" +
		       "Beta version November 1996";
	}

	// Inizializza applet aggiungendo bottone per login
	public void init() {
		buttonLogin = new Button("Login");
		add(buttonLogin);

		resize(320, 240);
	}

	// Controlla se viene premuto il bottone di login
	public boolean action(Event e, Object arg) {
		if (e.target instanceof Button && arg.equals("Login")) {
			if(!LoginDialogActive) {
				LoginDialogActive = true;

				myLoginDialogFrame = new Frame();
				myLoginDialog = new LoginDialog(this);
			}
		}
		return true;
	}

	// Avvia l'esecuzione dell'applet
	public void start() {
		if (VL_MainThread == null) {
			VL_MainThread = new Thread(this);
			VL_MainThread.start();
		}
	}
	
	// Ferma l'esecuzione dell'applet
	public void stop() {
		if (VL_MainThread != null) {
			VL_MainThread.stop();
			VL_MainThread = null;
		}
	}

	// Visualizza messaggio attesa caricamento oppure fotogramma
	public void paint(Graphics g) {
		if (VL_AllLoaded) {
			Rectangle r = g.getClipRect();
			
			g.clearRect(r.x, r.y, r.width, r.height);
			displayImage(g);
		}
		else
			g.drawString("Loading images...", 10, 20);
	}

	// Visualizza uno dei fotogrammi dell'animazione
	public void displayImage(Graphics g) {
		if (!VL_AllLoaded)
			return;

		g.drawImage(VL_Images[VL_CurrImageNo], 
				   (size().width - VL_ImgWidth)   / 2,
				   (size().height - VL_ImgHeight) / 2, null);
	}

	// Aggiorna il numero dei fotogrammi caricati
	public boolean imageUpdate(Image img, int flags, int x, int y, int w, int h) {
		if(VL_AllLoaded) return false;

		if ((flags & ALLBITS)==0) return true;

		if (++VL_CurrImageNo == NUM_IMAGES) {
			VL_CurrImageNo = 0;
			VL_AllLoaded = true;
		}				

		return false;
	}

	// Carica i fotogrammi che compongono l'animazione,
	// e gestisce tutte le operazioni sulla base dello
	// stato delle variabili
	public void run() {
		repaint();

		VL_Graphics = getGraphics();
		VL_CurrImageNo = 0;
		VL_Images = new Image[NUM_IMAGES];

		String strImage;

		// For each image in the animation, this method first constructs a
		// string containing the path to the image file; then it begins loading
		// the image into the VL_Images array.  Note that the call to getImage
		// will return before the image is completely loaded.
		for (int i = 1; i <= NUM_IMAGES; i++) {
			strImage = "images/img00" + ((i < 10) ? "0" : "") + i + ".gif";
            VL_Images[i-1] = getImage(getDocumentBase(), strImage);
			if (VL_ImgWidth == 0) {
				try	{
					// The getWidth() and getHeight() methods of the Image class
					// return -1 if the dimensions are not yet known. The
					// following code keeps calling getWidth() and getHeight()
					// until they return actual values (executed only once).
					while ((VL_ImgWidth = VL_Images[i-1].getWidth(null)) < 0)
						Thread.sleep(1);

					while ((VL_ImgHeight = VL_Images[i-1].getHeight(null)) < 0)
						Thread.sleep(1);						
				} catch (InterruptedException e) { }
			}
			VL_Graphics.drawImage(VL_Images[i-1], -1000, -1000, this);
		}

		while (!VL_AllLoaded) {
			try	{
				Thread.sleep(10);
			} catch (InterruptedException e) { }
		}
		
		repaint();

		// Il ciclo seguente viene ripetuto all'infinito
		while (true) {
			try {

				// Leggo lo stato e svolgo tutte le operazioni

				// Utente ha riempito il pannello di login
				if(LoginOKPressed && myClient==null) {
					LoginOKPressed = false;

					// Inizializzo connessione ed autenticazione
					myClient = new LabClient(this);
					String data[] = { userName, cryptedPassword };
					boolean access[] = myClient.Authentication(data);

					// Ricevo permessi e visualizzo risorse
					if (access!=null && access.length>0) {
						System.out.println("Ricevuto accessi");
						myResources = new LabResources(access);
						myResourcesFrame = new LabResourcesFrame(this);
					} else {
						System.out.println("Accessi non ricevuti");
					}

					// Pu� essere avviata la simulazione
					while(true) {
						if(executionCanStart) {
							
							// Viene avviato protocollo Request/Reply
							String commands[] = { executionCommand };
							String results[] = myClient.RequestReply(commands);

							if(results==null) {
								System.out.println("VL.run fallito");
							} else for (int zx=0; zx<results.length; zx++) {
								System.out.println(results[zx]);
							}

							break;
						}
					}

					myClient.close();
					myClient = null;
				}

				// Tutto quello che segue serve solo per animazioni
				displayImage(VL_Graphics);
				VL_CurrImageNo++;
				if (VL_CurrImageNo == NUM_IMAGES)
					VL_CurrImageNo = 0;

				Thread.sleep(50);
			} catch (InterruptedException e) {
				stop();
			}
		}
	}
 
	// Usato per settare le variabili riservate
	public void setInfo(String un, String cp) {
		userName = new String(un);
		cryptedPassword = new String(cp);
	}

}
